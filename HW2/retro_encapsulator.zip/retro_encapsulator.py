# Dumb Script to take a folder of files, and put each file into its own folder
import os
import sys
import shutil

def encapsulator(source_folder):
    for filename in os.listdir(source_folder):
        folder_name = filename[:-4]
        print(folder_name)
        print(filename)
        os.makedirs(os.path.join(source_folder,folder_name))
        shutil.move(os.path.join(source_folder,filename),os.path.join(source_folder,folder_name,filename))


if __name__=="__main__":
    encapsulator(sys.argv[1])